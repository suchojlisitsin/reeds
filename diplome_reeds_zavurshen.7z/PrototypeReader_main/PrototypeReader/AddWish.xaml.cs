﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PrototypeReader
{
    /// <summary>
    /// Interaction logic for AddWish.xaml
    /// </summary>
    public partial class AddWish : Window
    {
        public AddWish()
        {
            InitializeComponent();
        }

        public string title = null;
        public string author = null;
        public string status = null;
        public string rating = null;

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            title = tbTitle.Text;
            author = tbAuthor.Text;

            Wishlist.AddWish(title, author, status, rating);
            ((Readlist)this.Owner).ReloadList();
        }


        private void rbtnStatus_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton ck = sender as RadioButton;
            status = ck.Content.ToString();
        }
        private void rbtnRating_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton ck = sender as RadioButton;
            rating = ck.Content.ToString();
        }
    }
}
