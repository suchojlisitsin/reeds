﻿using System;
using System.Collections.Generic;
using System.IO.Compression;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace PrototypeReader
{
    /// <summary>
    /// Interaction logic for Books.xaml
    /// </summary>
    public partial class Books : Window
    {

        public Books()
        {
            InitializeComponent();
        }

        private void openFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.ShowDialog();
            string path = openFileDialog.FileName;
            LocalBooksList.AddLocalBook(path);
            CloseMethod(LocalBooksList.GetLocalBookByFilepath(path));
        }
        private void CloseMethod(LocalBook book) 
        {
            Router.OpenReader(this, book);
        }
      

        private void openLibrary_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenLibrary(this);
        }

        private void openReadlist_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenReadlist(this);
        }

        private void lbLocalBooks_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            CloseMethod(LocalBooksList.GetLocalBookByName(((ListBox)sender).SelectedItem.ToString()));
        }

        private void lbLocalBooks_Initialized(object sender, EventArgs e)
        {
            List<string> books = LocalBooksList.GetLocalBookNames();
            lbLocalBooks.ItemsSource = books;
        }

        private void openStatistics_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenStatistics(this);
        }

        private void openProfile_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenProfile(this);
        }

        private void Window_Initialized(object sender, EventArgs e)
        {
            if (!Client.IsLoggedIn())
            {
                openLibrary.Visibility = Visibility.Collapsed;
                openProfile.Visibility = Visibility.Collapsed;
                openStatistics.Visibility = Visibility.Collapsed;
            }
        }
    }
}
