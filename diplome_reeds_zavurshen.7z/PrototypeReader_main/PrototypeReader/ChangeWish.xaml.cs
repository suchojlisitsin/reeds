﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PrototypeReader
{
    /// <summary>
    /// Interaction logic for ChangeWish.xaml
    /// </summary>
    public partial class ChangeWish : Window
    {
        public Wish wish = null;
        public string title = null;
        public string author = null;
        public string status = null;
        public string rating = null;

        public ChangeWish()
        {
            InitializeComponent();
        }
        public void SetWish(string text) 
        {
            wish = Wishlist.GetWishByNames(text);
            tbTitle.Text = wish.Title;
            tbAuthor.Text = wish.Author;
        }
        private void rbtnStatus_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton ck = sender as RadioButton;
            status = ck.Content.ToString();
        }
        private void rbtnRating_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton ck = sender as RadioButton;
            rating = ck.Content.ToString();
        }

        private void btnConfirm_Click(object sender, RoutedEventArgs e)
        {
            title = tbTitle.Text;
            author = tbAuthor.Text;

            Wishlist.ChangeWish(wish, title, author, status, rating);
            ((Readlist)this.Owner).ReloadList();
            this.Close();
        }

    }
}
