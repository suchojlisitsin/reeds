﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PrototypeReader
{
    /// <summary>
    /// Interaction logic for ChapterReader.xaml
    /// </summary>
    public partial class ChapterReader : Window
    {

        public static LocalBook book;

        public ChapterReader()
        {
            InitializeComponent();
        }
        public static void SetBook(LocalBook newBook)
        {
            book = newBook;
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenBooks(this);
        }

        public void Read()
        {
            book.Chapters = FileReader.getEPUBChapterList(book.Filepath);
            changeText();
        }

        private void btnPrevious_Click(object sender, RoutedEventArgs e)
        {
            if (book.CurrentChapter > 0)
            {
                book.CurrentChapter--;
                changeText();
            }
        }

        private void btnNext_Click(object sender, RoutedEventArgs e)
        {
            if (book.CurrentChapter < (book.Chapters.Count-1)) { 
                book.CurrentChapter++;
                changeText();
            }
        }

        

        private void changeText() {
            if (book.CurrentChapter > book.Chapters.Count)
            {
                book.CurrentChapter = 0;
            }
            textArea.Text = FileReader.getEPUBChapterText(book.Filepath, book.Chapters[book.CurrentChapter]);


         
            lblPages.Content = book.CurrentChapter;
            LocalBooksList.ChangeCurrentChapterByFilepath(book.Filepath, book.CurrentChapter);
        }

        private void openBooks_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenBooks(this);
        }

        private void openReadlist_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenReadlist(this);
        }

        private void openStatistics_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenStatistics(this);
        }

        private void Window_Initialized(object sender, EventArgs e)
        {
            if (!Client.IsLoggedIn()) 
            {
                openStatistics.Visibility = Visibility.Collapsed;
            }
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            LocalBooksList.SaveLocalBooksList();
        }
    }
}
