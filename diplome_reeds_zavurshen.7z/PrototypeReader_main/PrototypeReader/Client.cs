﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Shapes;

namespace PrototypeReader
{
    internal class Client
    {

        public static TcpClient client = new TcpClient("127.0.0.1", 8080);
        public static bool loggedIn = false;
        public static StreamReader reader = new StreamReader(client.GetStream());
        public static StreamWriter writer = new StreamWriter(client.GetStream());
        
        public static bool SignIn(string username, string password) 
        {
            try
            {
                writer.WriteLine("login {0} {1}", username, password);
                writer.Flush();
                if (reader.ReadLine() == "True")
                {
                    loggedIn = true;
                    return true;
                }
                return false;
            }
            catch {
                return false;
            }
        }
        public static bool SignUp(string email, string username, string password)
        {
            try
            {
                
                writer.WriteLine("register {0} {1} {2}", email, username, password);
                writer.Flush();
                if (reader.ReadLine() == "True")
                {
                    loggedIn = true;
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }
        public static bool IsConnected() 
        {
            try
            {
                return client.Connected;
            }
            catch {
                return false;
            }
        }
        public static bool IsLoggedIn()
        {
            try
            {
                return loggedIn;
            }
            catch
            {
                return false;
            }
        }

        public static List<string> GetBooks()
        {
            try
            {
                writer.WriteLine("books");
                writer.Flush();
                string book = reader.ReadLine();
                List<string> books = book.Split("///").ToList();
                return books;
            }
            catch
            {
                return null;
            }
        }
        public static string GetText(string title)
        {
            try
            {
                writer.WriteLine($"text {title}");
                writer.Flush();
                string text = "", line;

                while ((line = reader.ReadLine()) != "end")
                {
                    text += line + "\n";
                }
                return text;
            }
            catch
            {
                return "Problem with loading";
            }
        }

        public static bool SyncToServer() 
        {
            try
            {
                writer.WriteLine($"sync to {Wishlist.GetString()} {LocalBooksList.GetString()}");
                writer.Flush();
            }
            catch
            {
                return false;
            }
            return false;
        }
        public static bool SyncFromServer()
        {
            try
            {
                writer.WriteLine($"sync from");
                writer.Flush();
                string lists = reader.ReadLine();
                Console.WriteLine(lists);


                //split
                string[] list = lists.Split(";;");
                list[0] = list[0].Remove(list[0].Length - 2, 2);
                list[1] = list[1].Remove(list[1].Length - 2, 2);
                //wish
                string[] wishes = list[0].Split("..");
                List<Wish> wishlist= new List<Wish>();
                foreach (string wish in wishes)
                {
                    string[] data = wish.Split("::");
                    wishlist.Add(new Wish(data[0], data[1], data[2], data[3]));
                }
                Wishlist.SyncWishlist(wishlist);
                //localbook
                List<LocalBook> localbookslist = new List<LocalBook>();
                string[] books = list[1].Split("..");
                foreach (string book in books)
                {
                    string[] data = book.Split("::");
                    localbookslist.Add(new LocalBook(data[0], Convert.ToInt32(data[1]), Convert.ToInt32(data[2])));
                }
                LocalBooksList.SyncLocalBooksList(localbookslist);
            }
            catch
            {
                return false;
            }
            return false;
        }
        public static void SetUser() 
        {
            writer.WriteLine($"user");
            writer.Flush();

            User.SetUser(reader.ReadLine());
        }
        public static void SaveProfile(string genre, string nickname, string type) 
        {
            writer.WriteLine($"profile {genre} {nickname} {type}");
            writer.Flush();
        }
    }
}
