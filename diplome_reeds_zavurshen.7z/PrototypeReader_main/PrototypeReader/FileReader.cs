﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Windows;
using System.Windows.Media.Media3D;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;

public class FileReader
{
	static public string GetText(string path) 
    {
		string text = "";
        foreach (string line in System.IO.File.ReadLines(path))
        {
			text += line + "\n";
		}
        return text;
	}

    public static string ReadHTMLFile(string path)
    {
        string htmlText = "";
        foreach (string line in System.IO.File.ReadLines(path))
        {
            htmlText += line+"\n";
        }
        return ReadTextHTMLText(htmlText);
    }

	
    static public string ReadTextHTMLText(string text)
    {
        string htmlText = "";
        List<string> lines = new List<string>();

        GetBodyLines(ref lines, text);
        //translate space tags
        lines = GetTranaslatedSpaceTags(ref lines);
        //translate style tags
        TranslateStyleTags(ref lines);

        for (int i = 0; i < lines.Count; i++) {
            htmlText += "\t" + lines[i] + "\n";
        }

        return htmlText;
    }
    public static void GetBodyLines(ref List<string> lines, string text) {
        StringReader sr = new StringReader(text);
        while (true) {
            string line = sr.ReadLine();
            while(!line.Contains("<body")) {
                line = sr.ReadLine();
            }
                line = line.Substring(line.IndexOf("<body") + 4);
                line = line.Substring(line.IndexOf(">")+1);
                while (!line.Contains("</body"))
                {
                if (String.IsNullOrEmpty(line))
                {
                    line = sr.ReadLine();
                    continue;
                }
                    lines.Add(line);
                    line = sr.ReadLine();
                }
            break;
            
        }
    }

    public static List<string> GetTranaslatedSpaceTags(ref List<string> lines) {
        List<string> translated = new List<string>();

        string text = "";
        foreach (string line in lines)
        {
            text += line;
        }
        while (text.Contains("<p") || text.Contains("<h")) {
            int pTag = text.IndexOf("<p");
            int hTag = text.IndexOf("<h");
            if (text.Contains("<p") && text.Contains("<h")) {
                if (pTag < hTag)
                {
                    addPBlock(ref text, ref translated);
                }
                else
                {
                    addHBlock(ref text, ref translated);
                }
            } else
            if (text.Contains("<p")) {
                addPBlock(ref text, ref translated);
            } else if (text.Contains("<h")) {
                addHBlock(ref text, ref translated);
            }

        }
        return translated;
     
    }
    public static void addPBlock(ref string text, ref List<string> translated)
    {
        string block = text.Substring(text.IndexOf("<p"));//make push text method for readability
        text = text.Substring(text.IndexOf("<p"));
        text = text.Substring(text.IndexOf(">"));
        if (text.IndexOf("</p") != -1)
        {
            text = text.Substring(text.IndexOf("</p"));
            text = text.Substring(text.IndexOf(">"));

            block = block.Substring(block.IndexOf(">") + 1);
            int length = block.IndexOf("</p");

            block = block.Substring(0, length);


            translated.Add(block);
        }
    }
    public static void addHBlock(ref string text, ref List<string> translated)
    {
        //make push text method for readability
        string block = text.Substring(text.IndexOf("<h"));
        text = text.Substring(text.IndexOf("<h"));
        text = text.Substring(text.IndexOf(">"));
        if (text.IndexOf("</h") != -1)
        {
            text = text.Substring(text.IndexOf("</h"));
            text = text.Substring(text.IndexOf(">"));

            block = block.Substring(block.IndexOf(">") + 1);
            int length = block.IndexOf("</h");

            block = block.Substring(0, length);


            translated.Add(block);
        }
    }

    public static void TranslateStyleTags(ref List<string> lines) 
    {
        for (int i = 0; i < lines.Count; i++) 
        {
            while (lines[i].Contains("<") || lines[i].Contains(">"))
            {
                int openingIndex = lines[i].IndexOf("<");
                int closingIndex= lines[i].IndexOf(">");

                int length = closingIndex - openingIndex + 1;

                lines[i] = lines[i].Remove(openingIndex, length);
            }
        }
    }
    static public List<string> getEPUBChapterList(string path)
    {
        using (FileStream zipToOpen = new FileStream(path, FileMode.Open))
        {
            using (ZipArchive archive = new ZipArchive(zipToOpen, ZipArchiveMode.Read))
            {
                foreach (ZipArchiveEntry entry in archive.Entries)
                {
                    //content
                    if (entry.FullName.EndsWith("content.opf", StringComparison.OrdinalIgnoreCase))
                    {
                        string text;
                        using (StreamReader sr = new StreamReader(entry.Open()))
                        {
                            text = sr.ReadToEnd();
                        }
                        return chapterList(text);
                    }
                }
            }
        }
        return null;
    }
    static public List<string> chapterList(string contents)
    {
        StringReader sr = new StringReader(contents);
        List<string> chapters = new List<string>();
        while (true)
        {
            string line = sr.ReadLine();
            if (line == null)
            {
                break;
            }
            if (line.Contains("<manifest>"))
            {
                line = sr.ReadLine();
                while (!line.Contains("</manifest>"))
                {
                    if (findHTMLFiles(line) != null)
                    {
                        chapters.Add(findHTMLFiles(line));
                    }
                    line = sr.ReadLine();
                }
            }


        }
        return chapters;
    }

    static public string findHTMLFiles(string line)
    {
        if (line.IndexOf("href=\"") != -1)
        {
            line = line.Substring(line.LastIndexOf("href=\"") + 6);
            line = line.Substring(0, line.IndexOf("\""));
            if (line.Contains("html") || line.Contains("htm") || line.Contains("xhtml"))
            {
                return line;
            }
            else
            {
                return null;
            }
        }
        else
        {
            return null;
        }
    }
    static public string getEPUBChapterText(string path, string chapter) 
    {
        using (FileStream zipToOpen = new FileStream(path, FileMode.Open))
        {
            using (ZipArchive archive = new ZipArchive(zipToOpen, ZipArchiveMode.Read))
            {
                foreach (ZipArchiveEntry entry in archive.Entries)
                {
                    if (entry.FullName.EndsWith(chapter, StringComparison.OrdinalIgnoreCase))
                    {
                        string text;
                        using (StreamReader sr = new StreamReader(entry.Open()))
                        {
                            text = sr.ReadToEnd();
                        }
                        text = ReadTextHTMLText(text);
                        return text;
                    }
                }
            }
        }
        return null;
    }
}
