﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PrototypeReader
{
    /// <summary>
    /// Interaction logic for Library.xaml
    /// </summary>
    public partial class Library : Window
    {
        public Library()
        {
            InitializeComponent();
        }

        private void openBooks_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenBooks(this);
        }

        private void openReadlist_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenReadlist(this);
        }

        private void lbBooks_Initialized(object sender, EventArgs e)
        {
            List<string> books = Client.GetBooks();
            lbBooks.ItemsSource = books;
        }

        private void lbBooks_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Router.OpenReader(this, Client.GetText(((ListBox)(sender)).SelectedItem.ToString()));
        }

        private void openStatistics_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenStatistics(this);
        }

        private void openProfile_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenProfile(this);
        }
    }
}
