﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrototypeReader
{
    public class LocalBook
    {

        public string Name { get; set; }
        public string Filepath { get; set; }
        public int Type { get; set; }
        public int CurrentChapter { get; set; }
        public List<string> Chapters { get; set; }

        public LocalBook() 
        {
        
        }
        public LocalBook(string filepath)
        {
            Type = GetTypeByFilepath(filepath);
            Filepath = filepath;
            while (filepath.IndexOf("\\") != -1){
                int pos = filepath.IndexOf("\\")+1;
                filepath = filepath.Substring(pos);
            }
            int size = filepath.IndexOf(".");
            Name = filepath.Substring(0, size);
        }
        public LocalBook(string name, string filepath) 
        {
            Name = name;
            Filepath = filepath;
        }

        public LocalBook(string name, string filepath, int type)
        {
            Name = name;
            Filepath = filepath;
            Type = type;
        }
        public LocalBook(string filepath, int currentChapter)
        {
            Filepath = filepath;
            Type = GetTypeByFilepath(filepath);
            CurrentChapter = currentChapter;
            while (filepath.IndexOf("\\") != -1)
            {
                int pos = filepath.IndexOf("\\") + 1;
                filepath = filepath.Substring(pos);
            }
            int size = filepath.IndexOf(".");
            Name = filepath.Substring(0, size);
        }
        public LocalBook(string filepath, int type, int currentChapter)
        {
            Filepath = filepath;
            Type = type;
            CurrentChapter = currentChapter;
            while (filepath.IndexOf("\\") != -1)
            {
                int pos = filepath.IndexOf("\\") + 1;
                filepath = filepath.Substring(pos);
            }
            int size = filepath.IndexOf(".");
            Name = filepath.Substring(0, size);
        }

        public LocalBook(string name, string filepath, int type, int currentChapter)
        {
            Name = name;
            Filepath = filepath;
            Type = type;
            CurrentChapter = currentChapter;
        }

        public static int GetTypeByFilepath(string filepath)
        {
            if (filepath.EndsWith(".text") || filepath.EndsWith(".txt"))
            {
                return 0;
            }
            else if (filepath.EndsWith(".html") || filepath.EndsWith(".htm") || filepath.EndsWith(".xhtml"))
            {
                return 1;
            }
            else if (filepath.EndsWith(".epub"))
            {
                return 2;
            }
            else
            {
                return 0;
            }
        }
    }
}
