﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace PrototypeReader
{
    class LocalBooksList
    {
        public static List<LocalBook> localBooks = new List<LocalBook>();
        public LocalBooksList() 
        {

        }
        public static void ReloadLocalBooksList()
        {
            try
            {
                localBooks.Clear();
                var lines = System.IO.File.ReadLines(@"LocalBooks.fp");
                for (int i = 0; i < lines.Count(); i++) 
                {
                    string[] elements = lines.ElementAt(i).Split("::");
                    AddLocalBookFromList(elements[1], Convert.ToInt32(elements[3]));

                }
            }
            catch(Exception ex) 
            {
                //exception handling
            }
            
        }
        public static List<string> GetLocalBookNames() 
        {
            ReloadLocalBooksList();
            List<string> names = new List<string>();
            foreach (LocalBook localBook in localBooks) 
            {
                names.Add(localBook.Name);
            }
            return names;
        }
        public static void AddLocalBookFromList(string filepath, int currentChapter)
        {
            if (IsUnique(filepath))
            {
                localBooks.Add(new LocalBook(filepath, currentChapter));
            }
        }
        public static void AddLocalBook(string filepath) 
        {
            if (IsUnique(filepath))
            {
                localBooks.Add(new LocalBook(filepath));
                SaveLocalBooksList();
            }    
        }
        public static void AddLocalBook(string filepath, int type, int currentChapter)
        {
            if (IsUnique(filepath))
            {
                localBooks.Add(new LocalBook(filepath, type, currentChapter));
                SaveLocalBooksList();
            }
        }
        public static void SaveLocalBooksList() 
        {
            StreamWriter writer = new StreamWriter("LocalBooks.fp");
            foreach (LocalBook book in localBooks) 
            {
                writer.WriteLine($"{book.Name}::{book.Filepath}::{book.Type}::{book.CurrentChapter}");
                writer.Flush();
            } 
            writer.Close();
        }
        public static bool IsUnique(string filepath) 
        {
            foreach(LocalBook book in localBooks) 
            {
                if (book.Filepath == filepath)
                {
                    return false;
                }
            }
            return true;
        }
        public static LocalBook GetLocalBookByFilepath(string filepath) 
        {
            foreach (LocalBook book in localBooks)
            {
                if (book.Filepath == filepath)
                {
                    return book;
                }
            }
            return null;
        }
        public static LocalBook GetLocalBookByName(string name)
        {
            foreach (LocalBook book in localBooks)
            {
                if (book.Name == name)
                {
                    return book;
                }
            }
            return null;
        }
        public static void ChangeCurrentChapterByFilepath(string filepath, int currentChapter) 
        {
            foreach (LocalBook book in localBooks)
            {
                if (book.Filepath == filepath)
                {
                    book.CurrentChapter = currentChapter;
                    SaveLocalBooksList();
                }
            }
        }
        public static string GetString() 
        {
            ReloadLocalBooksList();
            string send = "";
            foreach (LocalBook book in localBooks)
            {
                book.Filepath = book.Filepath.Replace(@"\", @"\\");
                send += $"{book.Filepath}::{book.Type}::{book.CurrentChapter}..";
            }
            send += ";;";
            return send;
        }
        public static void SyncLocalBooksList(List<LocalBook> books) 
        { 
            localBooks.Clear();
            foreach (LocalBook book in books)
            {
                AddLocalBook(book.Filepath, book.Type, book.CurrentChapter);
            }
            SaveLocalBooksList();
        }
    }
}
