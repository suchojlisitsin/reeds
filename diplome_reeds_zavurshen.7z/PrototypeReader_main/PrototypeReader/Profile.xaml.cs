﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PrototypeReader
{
    /// <summary>
    /// Interaction logic for Profile.xaml
    /// </summary>
    public partial class Profile : Window
    {
        public Profile()
        {
            InitializeComponent();
        }

        private void openBooks_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenBooks(this);
        }

        private void openLibrary_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenLibrary(this);
        }

        private void openReadlist_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenReadlist(this);
        }
        private void openStatistics_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenStatistics(this);
        }
        private void btnSyncToServer_Click(object sender, RoutedEventArgs e)
        {
            Client.SyncToServer();
        }
        private void btnSyncFromServer_Click(object sender, RoutedEventArgs e)
        {
            Client.SyncFromServer();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            Client.SaveProfile(cbPreferredGenre.SelectedValue.ToString(), tbNickname.Text, cbType.SelectedValue.ToString());
        }

        private void Window_Initialized(object sender, EventArgs e)
        {
            tbUsername.Text = User.Username;
            if (!String.IsNullOrWhiteSpace(User.Nickname))
            {
                tbNickname.Text = User.Nickname;
            }
            else 
            {
                tbNickname.Text = "";
            }
        }
    }
}
