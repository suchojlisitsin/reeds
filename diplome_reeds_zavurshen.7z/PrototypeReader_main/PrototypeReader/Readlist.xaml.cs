﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PrototypeReader
{
    /// <summary>
    /// Interaction logic for Readlist.xaml
    /// </summary>
    public partial class Readlist : Window
    {
        public Readlist()
        {
            InitializeComponent();
        }


        private void openBooks_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenBooks(this);
        }

        private void openServerLibrary_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenLibrary(this);
        }

        private void lbWishlist_Initialized(object sender, EventArgs e)
        {
            ReloadList();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (lbWishlist.SelectedItem != null) 
            {
                Router.OpenChangeWish(this, (string)lbWishlist.SelectedItem);
            }
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenAddWish(this);
        }
        public void ReloadList()
        {
            List<string> names = Wishlist.GetWishesTitlesAndAuthors();
            lbWishlist.ItemsSource = names;
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            Wishlist.SaveWishlist();
        }

        private void openStatistics_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenStatistics(this);
        }

        private void openProfile_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenProfile(this);
        }

        private void Grid_Initialized(object sender, EventArgs e)
        {
            if (!Client.IsLoggedIn())
            {
                openServerLibrary.Visibility = Visibility.Collapsed;
                openProfile.Visibility = Visibility.Collapsed;
                openStatistics.Visibility = Visibility.Collapsed;
            }
        }
    }
}
