﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace PrototypeReader
{
    internal class Router
    {
        public static void OpenSignUp(Window previous) 
        {
            SignUp signUp = new SignUp();
            signUp.Show();
            previous.Close();
        }
        public static void OpenSignIn(Window previous)
        {
            SignIn signIn = new SignIn();
            signIn.Show();
            previous.Close();
        }
        public static void OpenReader(Window previous, string text) 
        {
            TextReader textReader = new TextReader();
            textReader.SetText(text);
            textReader.Show();
            previous.Close();
        }
        public static void OpenReader(Window previous, LocalBook book)
        {
            string text = "";
            switch (book.Type)
            {
                case 0:
                    text = FileReader.GetText(book.Filepath);
                    break;
                case 1:
                    text = FileReader.ReadHTMLFile(book.Filepath);
                    break;
                case 2:
                    OpenChapterReader(previous, book);
                    return;
                    break;
            }
            OpenReader(previous, text);
        }
        public static void OpenChapterReader(Window previous, LocalBook book)
        {
            ChapterReader chapterReader = new ChapterReader();
            ChapterReader.SetBook(book);
            chapterReader.Show();
            chapterReader.Read();
            previous.Close();
        }
        public static void OpenBooks(Window previous)
        {
            Books booksWindow = new Books();
            booksWindow.Show();
            previous.Close();
        }
        public static void OpenLibrary(Window previous)
        {
            Library library = new Library();
            library.Show();
            previous.Close();

        }
        public static void OpenReadlist(Window previous)
        {
            Readlist readlist = new Readlist();
            readlist.Show();
            previous.Close();
        }
        public static void OpenAddWish(Window previous)
        {
            AddWish addWishWindow = new AddWish();
            addWishWindow.Owner = previous;
            addWishWindow.Show();
        }
        public static void OpenChangeWish(Window previous, string wish)
        {
            ChangeWish changeWishWindow = new ChangeWish();
            changeWishWindow.Owner = previous;
            changeWishWindow.SetWish(wish);
            changeWishWindow.Show();
        }
        public static void OpenProfile(Window previous)
        {
            Client.SetUser();
            Profile profile = new Profile();
            profile.Show();
            previous.Close();
        }
        public static void OpenStatistics(Window previous)
        {
            Client.SetUser();
            Statistics statistics = new Statistics();
            statistics.Show();
            previous.Close();
        }
    }
}
