﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PrototypeReader
{
    /// <summary>
    /// Interaction logic for SignIn.xaml
    /// </summary>
    public partial class SignIn : Window
    {
        public SignIn()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenSignUp(this);
        }

        private void btnOffline_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenBooks(this);
        }

        private void btnSignIn_Click(object sender, RoutedEventArgs e)
        {
            string username = tbUsername.Text;
            string password = pswdBox.Password.ToString();
            if (Client.SignIn(username, password) == true) 
            {
                Router.OpenBooks(this);
            }
        }

        private void Window_Initialized(object sender, EventArgs e)
        {
            try
            {
                if (!Client.IsConnected())
                {
                    Router.OpenBooks(this);
                }
            }
            catch
            {
                Router.OpenBooks(this);
            }
        }
    }
}
