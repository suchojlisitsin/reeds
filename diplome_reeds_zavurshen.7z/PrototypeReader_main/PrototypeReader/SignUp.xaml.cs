﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PrototypeReader
{
    /// <summary>
    /// Interaction logic for SignUp.xaml
    /// </summary>
    public partial class SignUp : Window
    {
        public SignUp()
        {
            InitializeComponent();
        }

        private void btnSignIn_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenSignIn(this);
        }

        private void btnOffline_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenBooks(this);
        }

        private void btnSignUp_Click(object sender, RoutedEventArgs e)
        {
            string email = tbEmail.Text;
            string username = tbUsername.Text;
            string password = pswdBox.Password.ToString();
            if (String.IsNullOrEmpty(email) || String.IsNullOrEmpty(username) || String.IsNullOrEmpty(password))
            {
                return;
            }
            if (Client.SignUp(email, username, password) == true) 
            {
                Router.OpenBooks(this);
            }
        }

        private void Window_Initialized(object sender, EventArgs e)
        {
            try {
                if (!Client.IsConnected())
                {
                    Router.OpenBooks(this);
                }
            }
            catch 
            {
                Router.OpenBooks(this);
            }
            
        }
    }
}
