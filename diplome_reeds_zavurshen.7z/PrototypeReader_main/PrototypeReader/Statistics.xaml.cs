﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PrototypeReader
{
    /// <summary>
    /// Interaction logic for Statistics.xaml
    /// </summary>
    public partial class Statistics : Window
    {
        public Statistics()
        {
            InitializeComponent();
        }

        private void openBooks_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenBooks(this);
        }
        private void openLibrary_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenLibrary(this);
        }
        private void openReadlist_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenReadlist(this);
        }
        private void openProfile_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenProfile(this);
        }

        private void Window_Initialized(object sender, EventArgs e)
        {
            lblTimeT.Content = User.Time;
            lblBooksReadT.Content = User.BooksRead;
            lblLastReadT.Content = User.LastRead.Substring(0,User.LastRead.IndexOf("0:"));
            lblBooksToReadT.Content = User.BooksToRead;
            lblBooksReadingT.Content = User.BooksReading;
        }
    }
}
