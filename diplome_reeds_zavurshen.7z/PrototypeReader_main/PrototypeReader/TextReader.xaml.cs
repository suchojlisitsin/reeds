﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PrototypeReader
{
    /// <summary>
    /// Interaction logic for TextReader.xaml
    /// </summary>
    public partial class TextReader : Window
    {
        public TextReader()
        {
            InitializeComponent();
        }
        public void SetText(string text)
        {
            textArea.Text = text;
        }


        private void openStatistics_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenStatistics(this);
        }

        private void openProfile_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenProfile(this);
        }

        private void openBooks_Click(object sender, RoutedEventArgs e)
        {
            Router.OpenBooks(this);
        }

        private void Window_Initialized(object sender, EventArgs e)
        {
            if (!Client.IsLoggedIn())
            {
                openProfile.Visibility = Visibility.Collapsed;
                openStatistics.Visibility = Visibility.Collapsed;
            }
        }
    }
}
