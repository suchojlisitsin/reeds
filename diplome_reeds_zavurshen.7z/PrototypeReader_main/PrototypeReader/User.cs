﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace PrototypeReader
{
    class User
    {
        public static string Username { get; set; }
        public static string PrefferedGenre { get; set; }
        public static string Nickname { get; set; }
        public static string Type { get; set; }
        public static string LastRead { get; set; }
        public static string BooksRead { get; set; }
        public static string BooksToRead { get; set; }
        public static string BooksReading { get; set; }
        public static string Time { get; set; }

        public static void SetUser(string username, string prefferedGenre, string nickname, string type, 
            string lastRead, string booksRead, string booksToRead, string booksReading, string time)
        {
            Username = username;
            PrefferedGenre = prefferedGenre;
            Nickname = nickname;
            Type = type;
            LastRead = lastRead;
            BooksRead = booksRead;
            BooksToRead = booksToRead;
            BooksReading = booksReading;
            Time = time;
        }
        public static void SetUser(string data) 
        {
            string[] att = data.Split("::");
            SetUser(att[0], att[1], att[2], att[3], att[4], att[5], att[6], att[7], att[8]);
        }
    }
}
