﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using static System.Formats.Asn1.AsnWriter;

namespace PrototypeReader
{
    internal class Wishlist
    {
        public static List<Wish> wishes = new List<Wish>();
        public static List<String> GetWishesTitlesAndAuthors()
        {
            ReloadWishlist();

            List<String> names = new List<String>();
            foreach (Wish wish in wishes) 
            {
                names.Add($"{wish.Title} - {wish.Author} - Status: {wish.Status} - Score: {wish.Score}");
            }
            return names;
        }
        public static void ClearWishlist() 
        {
            wishes.Clear();
        }
        public static void AddWish(string title, string author, string status, string score) 
        {
            if (IsUnique(title, author))
            {
                wishes.Add(new Wish(title, author, status, score));
                SaveWishlist();
            }
        }
        public static void AddWishFromList(string title, string author, string status, string score)
        {
            if (IsUnique(title, author))
            {
                wishes.Add(new Wish(title, author, status, score));
            }
        }
        public static bool IsUnique(string title, string author)
        {
            if (String.IsNullOrEmpty(title) || String.IsNullOrEmpty(author)) 
            {
                return false;
            }
            foreach (Wish wish in wishes)
            {
                if (wish.Title == title && wish.Author == author)
                {
                    return false;
                }
            }
            return true;
        }
        public static Wish GetWishByNames(string text) 
        {

            int size = text.Substring(0, text.IndexOf(" - ")).Length;
            string title = text.Substring(0, size);
            string author = text.Substring(text.IndexOf(" - ")+3);
            size = author.IndexOf(" - ");
            author = author.Substring(0, size);

            foreach (Wish wish in wishes)
            {
                if (title == wish.Title && author == wish.Author) 
                {
                    return wish;
                }
            }
            return null;
        }
        public static void ChangeWish(Wish wish, string title = "Title", string author = "Author", string status = "Not started", string score = "3") 
        {
            wish.Title = String.IsNullOrEmpty(title) ? "Title" : title;
            wish.Author = String.IsNullOrEmpty(author) ? "Author" : author;
            wish.Status = String.IsNullOrEmpty(status) ? "Not started" : status;
            wish.Score = String.IsNullOrEmpty(score) ? "3" : score;
            SaveWishlist();
        }

        public static void ReloadWishlist()
        {
            
            try
            {
                var lines = System.IO.File.ReadLines(@"Wishlist.fp");
                wishes.Clear();
                for (int i = 0; i < lines.Count(); i++)
                {
                    var elements = lines.ElementAt(i).Split("::");
                    AddWishFromList(elements[0], elements[1], elements[2], elements[3]);

                }
            }
            catch (Exception ex)
            {
                //exception handling
            }

        }
        public static void SaveWishlist()
        {
            try
            {
                StreamWriter writer = new StreamWriter("Wishlist.fp");
                foreach (Wish wish in wishes)
                {
                    writer.WriteLine($"{wish.Title}::{wish.Author}::{wish.Status}::{wish.Score}");
                    writer.Flush();
                }
                writer.Close();
            }
            catch (Exception ex) 
            {
                //exception handling
            }
            
        }
        public static string GetString() 
        {
            ReloadWishlist();
            string send = "";
            foreach (Wish wish in wishes)
            {
                send += ($"{wish.Title}::{wish.Author}::{wish.Status}::{wish.Score}..");
                
            }
            send += ";;";
            return send;
        }

        public static void SyncWishlist(List<Wish> newWishes) 
        {
            ClearWishlist();
            foreach (Wish wish in newWishes) 
            {
                AddWish(wish.Title, wish.Author, wish.Status, wish.Score);
            }
            SaveWishlist();
        }
    }
}
