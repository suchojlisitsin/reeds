﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    internal class ClientIdentity
    {
        public int SessionId { get; set; }
        public int ClientId { get; set; }
        public string Name { get; set; }
        public DateTime TimeConnected { get; set; }
        public DateTime TimeDisonnected { get; set; }

        public ClientIdentity(int id) 
        {
            this.SessionId = id;
            TimeConnected = DateTime.Now;
        }
        public void SetId(int id) 
        {
            ClientId = id;
        }
        public void Disconnect(Data data) 
        {
            TimeDisonnected = DateTime.Now;
            data.LogTime(ClientId, TimeConnected, TimeDisonnected);
        }
    }
}
