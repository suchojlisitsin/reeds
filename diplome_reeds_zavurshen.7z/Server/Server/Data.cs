﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI;
using static System.Reflection.Metadata.BlobBuilder;

namespace Server
{
    internal class Data
    {
        private MySqlConnection sql;
        private MySqlCommand cmd;
        private MySqlDataReader rd;
        public Data() 
        {
            sql = new MySqlConnection("server=localhost;port=3306;database=reader;uid=root;pwd=159159159;");  
        }
        public bool LogInAccount(string username, string password)
        {
            try
            {
                sql.Open();  //Initiate connection to the db
                cmd = new MySqlCommand("SELECT * FROM users", sql);
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    if (rd.GetString(1) == username)
                    {
                        if (rd.GetString(3) == password)
                        {
                            sql.Close();
                            return true;
                        }
                        else
                        {
                            sql.Close();
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                sql.Close();
            }
            return false;
        }
        
        public bool RegisterAccount(string username, string email, string password)
        {
            try
            {
                sql.Open();  //Initiate connection to the db
                string insert = String.Format("INSERT INTO users(username, email, password) VALUES('{0}','{1}','{2}')", username, email, password);
                cmd = new MySqlCommand(insert, sql);

                if (cmd.ExecuteNonQuery() == 1)
                {
                    sql.Close();
                    return true;
                }
                sql.Close();
                return false;

            }
            catch (Exception ex)
            {
                sql.Close();
                return false;
            }
        }
        public int GetClientID(string username) 
        {
            try
            {
                sql.Open();  //Initiate connection to the db
                cmd = new MySqlCommand("SELECT * FROM users", sql);
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    if (rd.GetString(1) == username)
                    {
                        int id = Convert.ToInt32(rd.GetString(0));
                        sql.Close();
                        return id;
                    }
                }
            }
            catch (Exception ex)
            {
                sql.Close();
            }
            return -1;
        }
        public void LogTime(int client, DateTime timeConnected, DateTime timeDisconnected) 
        {
            TimeSpan time = timeDisconnected.Subtract(timeConnected);
            string connected = timeConnected.ToString("yyyy-MM-dd HH:mm");
            string disconnected = timeDisconnected.ToString("yyyy-MM-dd HH:mm");
            SaveLastRead(client, timeDisconnected.ToString("yyyy-MM-dd"));
            try
            {
                sql.Open();
                string insert = $"INSERT INTO logs(userId, connected, disconnected, time) VALUES({client}, '{connected}', '{disconnected}', '{time}');";
                cmd = new MySqlCommand(insert, sql);
                cmd.ExecuteNonQuery();
                sql.Close();

            }
            catch (Exception ex)
            {
                sql.Close();
            }
        }
        public bool SaveWishlist(List<Wish> wishes, ClientIdentity client)
        {
            try
            {
                RemoveOldWishes(client);
                sql.Open();
                for (int i = 0; i < wishes.Count; i++)
                {
                    string insert = $"INSERT INTO wishes(title, author, status, rating, userId) " +
                        $"VALUES('{wishes[i].Title}','{wishes[i].Author}','{wishes[i].Status}','{wishes[i].Score}','{client.ClientId}')";
                    cmd = new MySqlCommand(insert, sql);
                    cmd.ExecuteNonQuery();
                }
                sql.Close();
                return true;

            }
            catch (Exception ex)
            {
                sql.Close();
                return false;
            }
        }
        public bool RemoveOldWishes(ClientIdentity client) 
        {
            try
            {
                sql.Open();

                string delete = "DELETE FROM wishes WHERE userId='" + client.ClientId + "';";
                MySqlCommand cmd = new MySqlCommand(delete, sql);
                cmd.ExecuteNonQuery();

                sql.Close();
                return true;

            }
            catch (Exception ex)
            {
                sql.Close();
                return false;
            }
        }
        public bool SaveLocalBookslist(List<LocalBook> localbooks, ClientIdentity client)
        {
            try
            {
                RemoveOldLocalbooks(client);
                sql.Open();

                for (int i = 0; i < localbooks.Count; i++) 
                {
                    string insert = $"INSERT INTO localbooks(filename, type, currentChapter, userId) " +
                        $"VALUES('{localbooks[i].Filepath}','{localbooks[i].Type}'," +
                        $"'{localbooks[i].CurrentChapter}','{client.ClientId}')";
                    cmd = new MySqlCommand(insert, sql);
                    cmd.ExecuteNonQuery();
                }
                sql.Close();
                return true;

            }
            catch (Exception ex)
            {
                sql.Close();
                return false;
            }
        }
        public bool RemoveOldLocalbooks(ClientIdentity client)
        {
            try
            {
                sql.Open();

                string delete = "DELETE FROM localbooks WHERE userId='" + client.ClientId + "';";
                MySqlCommand cmd = new MySqlCommand(delete, sql);
                cmd.ExecuteNonQuery();

                sql.Close();
                return true;

            }
            catch (Exception ex)
            {
                sql.Close();
                return false;
            }
        }

        public bool RefreshLibraryBooks() 
        {
            DeleteOldLibraryBooks();
            SaveLibraryBooks();
            return true;
        }
        public bool DeleteOldLibraryBooks() 
        {
            try
            {
                sql.Open();

                string delete = "DELETE FROM librarybooks;";
                MySqlCommand cmd = new MySqlCommand(delete, sql);
                cmd.ExecuteNonQuery();

                sql.Close();
                return true;

            }
            catch (Exception ex)
            {
                sql.Close();
                return false;
            }
        }
        public bool SaveLibraryBooks()
        {
            List<LibraryBook> books = Library.GetLibraryBooks();
            try
            {
                sql.Open();
                for (int i = 0; i < books.Count; i++)
                {
                    string insert = $"INSERT INTO librarybooks(title, author, filepath) " +
                        $"VALUES('{books[i].Title}','{books[i].Author}','{books[i].Filepath}')";
                    cmd = new MySqlCommand(insert, sql);
                    cmd.ExecuteNonQuery();
                }
                sql.Close();
                return true;

            }
            catch (Exception ex)
            {
                sql.Close();
                return false;
            }
        }
        public List<Wish> GetWishList(int id) 
        {
            List<Wish> wishes = new List<Wish>();
            try
            {
                sql.Open();
                MySqlCommand cmd = new MySqlCommand($"SELECT * FROM wishes WHERE userId='{id}'", sql);
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    wishes.Add(new Wish(rd.GetString(1), rd.GetString(2), rd.GetString(3), rd.GetString(4)));
                }
                sql.Close();
                return wishes;

            }
            catch (Exception ex)
            {
                sql.Close();
                return wishes;
            }
        }
        public List<LocalBook> GetLocalBookList(int id) 
        {
            List<LocalBook> books = new List<LocalBook>();
            try
            {
                sql.Open();

                MySqlCommand cmd = new MySqlCommand($"SELECT * FROM localbooks WHERE userId='{id}'", sql);
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    books.Add(new LocalBook(rd.GetString(1), rd.GetString(2), rd.GetString(3)));
                }

                sql.Close();
                return books;

            }
            catch (Exception ex)
            {
                sql.Close();
                return books;
            }
        }
        public string GetUser(int id) 
        {
            GetBooks(id);
            GetTime(id);
            string data = "";
            try
            {
                sql.Open();

                MySqlCommand cmd = new MySqlCommand($"SELECT * FROM users WHERE id={id}", sql);
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    data += $"{rd.GetString(1)}::{rd.GetString(4)}::{rd.GetString(5)}::{rd.GetString(6)}::{rd.GetString(7)}::{rd.GetString(8)}::{rd.GetString(9)}::{rd.GetString(10)}::{rd.GetString(11)}";
                }

                sql.Close();
            }
            catch (Exception ex)
            {
                sql.Close();
            }
            return data;
        }
        public void GetBooks(int id)
        {
            int booksRead = 0;
            int booksToRead = 0;
            int booksReading = 0;
            try
            {
                sql.Open();
                MySqlCommand cmd = new MySqlCommand($"SELECT * FROM wishes WHERE userId={id}", sql);
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    switch (rd.GetString(3))
                    { 
                        case "Read":
                            booksRead++;
                            break;
                        case "Notstarted":
                            booksToRead++;
                            break;
                        case "Reading":
                            booksReading++;
                            break;
                    }

                }
                sql.Close();
                SaveBooks(id, booksRead, booksToRead, booksReading);
            }
            catch (Exception ex)
            {
                sql.Close();
            }
        }
        public void SaveBooks(int id, int booksRead, int booksToRead, int booksReading)
        {
            try
            {
                sql.Open();

                string insert = $"UPDATE users SET booksread={booksRead}, bookstoread={booksToRead}, booksreading={booksReading} WHERE id={id};";
                cmd = new MySqlCommand(insert, sql);
                cmd.ExecuteNonQuery();

                sql.Close();

            }
            catch (Exception ex)
            {
                sql.Close();
            }
        }
        public string GetTime(int id) 
        {
            TimeSpan time = new TimeSpan();
            try
            {
                sql.Open();
                MySqlCommand cmd = new MySqlCommand($"SELECT * FROM logs WHERE userId={id}", sql);
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    time = time.Add(TimeSpan.Parse(rd.GetString(4)));
                }
                sql.Close();
                SaveTime(id, time.ToString());
            }
            catch (Exception ex)
            {
                sql.Close();
            }
            return time.ToString();
        }
        public void SaveTime(int id, string time) 
        {
            try
            {
                sql.Open();
                string insert = $"UPDATE users SET time='{time}' WHERE id={id};";
                cmd = new MySqlCommand(insert, sql);
                cmd.ExecuteNonQuery();
                sql.Close();

            }
            catch (Exception ex)
            {
                sql.Close();
            }
        }
        public void SaveLastRead(int id, string time)
        {
            try
            {
                sql.Open();

                string insert = $"UPDATE users SET LastRead='{time}' WHERE id={id};";
                cmd = new MySqlCommand(insert, sql);
                cmd.ExecuteNonQuery();

                sql.Close();

            }
            catch (Exception ex)
            {
                sql.Close();
            }
        }
        public void SaveProfile(string genre, string nickname, string type, ClientIdentity client) 
        {
            try
            {
                sql.Open();

                string insert = $"UPDATE users SET prefferedgenre='{genre}', nickname='{nickname}', type='{type}' WHERE id={client.ClientId};";
                cmd = new MySqlCommand(insert, sql);
                cmd.ExecuteNonQuery();

                sql.Close();

            }
            catch (Exception ex)
            {
                sql.Close();
            }
        }
    }
}
