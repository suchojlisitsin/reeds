﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    internal class Library
    {
        public static string GetTitles() 
        {
            string titles = "";
            var files = Directory.GetFiles(@".\library");
            foreach (var filepath in files)
            {
                string file;
                file = filepath.Substring(0, filepath.Length - 4).Substring(filepath.IndexOf("y\\") + 2);
                titles += file + "///";
            }
            titles = titles.Substring(0, titles.Length-3);
            return titles;
        }
        public static string GetText(string filename) 
        {
            string filepath = @".\library\"+filename+".txt";
            string text = "";
            foreach (string line in System.IO.File.ReadLines(filepath))
            {
                text += line + "\n";
            }
            return text;
        }
        public static List<LibraryBook> GetLibraryBooks() 
        {
            List<LibraryBook> books = new List<LibraryBook>();
            
            var files = Directory.GetFiles(@".\library");
            foreach (var filepath in files)
            {
                string title = filepath.Substring(0, filepath.Length - 4).Substring(filepath.IndexOf("y\\") + 2);
                string author = title.Substring(0, title.Substring(0, title.IndexOf("___")).Length);
                title = title.Substring(title.IndexOf("___") + 3);
                author = author.Replace("_", " ");
                title = title.Replace("_", " ");

                books.Add(new LibraryBook(title, author, filepath));
            }
            return books;
        }
    }
}
