﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Server
{
    public class LocalBook
    {
        public string Name { get; set; }
        public string Filepath { get; set; }
        public string Type { get; set; }
        public string CurrentChapter { get; set; }

        public LocalBook( string filepath, string type, string currentChapter)
        {
            Filepath = filepath;
            Type = type;
            CurrentChapter = currentChapter;
        }
    }
}
