﻿using MySqlX.XDevAPI;
using Server;
using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using static System.Net.Mime.MediaTypeNames;

namespace Server
{
    public class MultiThreadedEchoServer
    {
        static int clientsConnected = 0;
        static Data data = new Data();

        private static void ProcessClientRequests(object argument)
        {
            TcpClient client = (TcpClient)argument;
            ClientIdentity clientId = new ClientIdentity(clientsConnected);
            clientsConnected++;
            try
            {
                StreamReader reader = new StreamReader(client.GetStream());
                StreamWriter writer = new StreamWriter(client.GetStream());
                string s = String.Empty;

                Console.WriteLine("New Client #{0} connected", clientId.SessionId);
                while (!((s = reader.ReadLine()) == null) && !(s.Equals("Exit")))
                {
                    Console.WriteLine("Client #{0} :: {1}", clientId.SessionId, s);
                    string[] req = s.Split(' ');
                    switch (req[0]) 
                    {
                        case "login":
                            writer.WriteLine(data.LogInAccount(req[1], req[2]));
                            writer.Flush();
                            clientId.SetId(data.GetClientID(req[1]));
                            break;
                        case "register":
                            writer.WriteLine(data.RegisterAccount(req[1], req[2], req[3]));
                            writer.Flush();
                            break;
                        case "books":
                            writer.WriteLine(Library.GetTitles());
                            writer.Flush();
                            break;
                        case "text":
                            writer.WriteLine(Library.GetText(req[1]));
                            writer.WriteLine("end");
                            writer.Flush();
                            break;
                        
                        case "user":
                            writer.WriteLine(data.GetUser(clientId.ClientId));
                            writer.Flush();
                            break;
                        case "profile":
                            data.SaveProfile(req[1], req[2], req[3], clientId);
                            break;
                        case "sync":
                            switch (req[1])
                            {
                                case "to":
                                    string lists = "";
                                    for (int i = 2; i < req.Length; i++)
                                    {
                                        lists += req[i];
                                    }
                                    Sync.SyncToServer(lists, data, clientId);
                                    break;
                                case "from":
                                    writer.WriteLine(Sync.SyncFromServer(clientId.ClientId, data));
                                    writer.Flush();
                                    break;
                            }
                            break;
                    }
                }
                reader.Close();
                writer.Close();
                client.Close();

                CloseConnection(clientId);
            }
            catch (IOException)
            {
                CloseConnection(clientId);
            }
            finally
            {
                if (client != null)
                {
                    client.Close();
                }
            }
        }
        private static void CloseConnection(ClientIdentity clientId)
        {
            clientId.Disconnect(data);
            Console.WriteLine("//Client #{0} :: IOException, closing connection", clientId.SessionId);
        }

        public static void Main()
        {
            data.RefreshLibraryBooks();
            TcpListener listener = null;
            try
            {
                listener = new TcpListener(IPAddress.Parse("127.0.0.1"), 8080);
                listener.Start();
                Console.WriteLine("Started Reeds server");
                Console.WriteLine("Open for new connections");
                while (true)
                {
                    TcpClient client = listener.AcceptTcpClient();
                    Thread t = new Thread(ProcessClientRequests);
                    t.Start(client);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                if (listener != null)
                {
                    listener.Stop();
                }
            }
        } 
    }
}