﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    internal class Sync
    {
        public static void SyncToServer(string lists, Data db, ClientIdentity client)
        {
            string[] list = lists.Split(";;");
            Console.WriteLine();
            Console.WriteLine();
            list[0]=list[0].Remove(list[0].Length - 2, 2);
            Console.WriteLine(list[0]);
            Console.WriteLine();
            list[1] = list[1].Remove(list[1].Length - 2, 2);
            Console.WriteLine(list[1]);


            //wishlist
            List<Wish> wishlist = new List<Wish>();
            string[] wishes = list[0].Split("..");
            foreach (string wish in wishes) 
            {
                string[] data = wish.Split("::");
                wishlist.Add(new Wish(data[0], data[1], data[2], data[3]));
            }

            db.SaveWishlist(wishlist, client);

            //localbooklist
            List<LocalBook> localbookslist = new List<LocalBook>();
            string[] books = list[1].Split("..");
            foreach (string book in books)
            {
                string[] data = book.Split("::");
                localbookslist.Add(new LocalBook(data[0], data[1], data[2]));
            }

            db.SaveLocalBookslist(localbookslist, client);
        }
        public static string SyncFromServer(int id, Data data) 
        {
            return GetWishListString(id, data) + GetLocalBookListString(id, data);
        }
        public static string GetWishListString(int id, Data data) 
        {
            string wishlist ="";
            List<Wish> wishes = data.GetWishList(id);
            foreach (Wish wish in wishes) 
            {
                wishlist += $"{wish.Title}::{wish.Author}::{wish.Status}::{wish.Score}..";
            }
            wishlist += ";;";
            return wishlist;
        }
        public static string GetLocalBookListString(int id, Data data)
        {
            string list = "";
            List<LocalBook> books = data.GetLocalBookList(id);
            foreach (LocalBook book in books)
            {
                list += $"{book.Filepath}::{book.Type}::{book.CurrentChapter}..";
            }
            list += ";;";
            return list;
        }
    }
}
