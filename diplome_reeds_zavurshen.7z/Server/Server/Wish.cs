﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    public class Wish
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public string Status { get; set; }
        public string Score { get; set; }
        public Wish(string title = "Title", string author = "Author", string status = "Not started", string score = "3")
        {
            Title = String.IsNullOrEmpty(title) ? "Title" : title;
            Author = String.IsNullOrEmpty(author) ? "Author" : author;
            Status = String.IsNullOrEmpty(status) ? "Not started" : status;
            Score = String.IsNullOrEmpty(score) ? "3" : score;
        }
    }
}
